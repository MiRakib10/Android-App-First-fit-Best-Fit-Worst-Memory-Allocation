package com.example.allocation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class worst_fit_allocation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worst_fit_allocation);
    }
}