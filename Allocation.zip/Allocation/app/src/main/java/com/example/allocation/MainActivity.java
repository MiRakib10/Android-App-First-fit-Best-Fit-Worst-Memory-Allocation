package com.example.allocation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    AppCompatButton First_fit,Best_fit,Worst_fit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        First_fit.findViewById(R.id.first_fit);
        Best_fit.findViewById(R.id.best_fit);
        Worst_fit.findViewById(R.id.worst_fit);

        First_fit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, first_fit_allocation.class));
            }
        });

        Best_fit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, best_fit_allocation.class));
            }
        });

        Worst_fit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, worst_fit_allocation.class));
            }
        });

    }
}
