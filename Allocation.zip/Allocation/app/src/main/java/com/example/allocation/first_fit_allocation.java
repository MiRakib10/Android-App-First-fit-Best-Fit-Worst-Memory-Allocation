package com.example.allocation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class first_fit_allocation extends AppCompatActivity {

    EditText p1, p2, p3, p4, b1, b2, b3, b4;

    int P1,P2,P3,P4,B1,B2,B3,B4,A1,A2,A3,A4;
    AppCompatButton allocate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_fit_allocation);
        p1.findViewById(R.id.p1);
        p2.findViewById(R.id.p2);
        p3.findViewById(R.id.p3);
        p4.findViewById(R.id.p4);

        b1.findViewById(R.id.b1);
        b2.findViewById(R.id.b2);
        b3.findViewById(R.id.b3);
        b4.findViewById(R.id.b4);

        allocate.findViewById(R.id.allocate_btn);



        P1 = Integer.parseInt(p1.getText().toString());
        P2 = Integer.parseInt(p2.getText().toString());
        P3 = Integer.parseInt(p3.getText().toString());
        P4 = Integer.parseInt(p4.getText().toString());


        B1 = Integer.parseInt(b1.getText().toString());
        B2 = Integer.parseInt(b2.getText().toString());
        B3 = Integer.parseInt(b3.getText().toString());
        B4 = Integer.parseInt(b4.getText().toString());

        allocate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                allocations();
                Intent intent=new Intent(first_fit_allocation.this, ffa_result.class);
                intent.putExtra("p1",P1).toString();
                intent.putExtra("p2",P2).toString();
                intent.putExtra("p3",P3).toString();
                intent.putExtra("p4",P4).toString();

                intent.putExtra("b1",B1).toString();
                intent.putExtra("b2",B2).toString();
                intent.putExtra("b3",B3).toString();
                intent.putExtra("b4",B4).toString();

                intent.putExtra("a1",A1).toString();
                intent.putExtra("a2",A2).toString();
                intent.putExtra("a3",A3).toString();
                intent.putExtra("a4",A4).toString();
                startActivity(intent);
            }
        });

    }
    void allocations(){
        int p[] = new int[4];
        int b[] = new int[4];

        int allocate[] = new int[4];
        p[0] = P1;
        p[1] = P2;
        p[2] = P3;
        p[3] = P4;

        b[0] = B1;
        b[1] = B2;
        b[2] = B3;
        b[3] = B4;

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (p[i] <= b[j]) {
                    b[j] = b[j] - p[i];
                    allocate[i] = j + 1;
                    break;
                }
            }
        }

        A1=allocate[0];
        A2=allocate[1];
        A3=allocate[2];
        A4=allocate[3];
    }

}
