package com.example.allocation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ffa_result extends AppCompatActivity {

    TextView one,two,three,four,One,Two,Three,Four,ONE,TWO,THREE,FOUR;
    String bs1,bs2,bs3,bs4,ps1,ps2,ps3,ps4,al1,al2,al3,al4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ffa_result);

        bs1=getIntent().getStringExtra("b1");
        bs2=getIntent().getStringExtra("b2");
        bs3=getIntent().getStringExtra("b3");
        bs4=getIntent().getStringExtra("b4");

        one.setText(bs1);
        two.setText(bs2);
        three.setText(bs3);
        four.setText(bs4);

        ps1=getIntent().getStringExtra("p1");
        ps2=getIntent().getStringExtra("p2");
        ps3=getIntent().getStringExtra("p3");
        ps4=getIntent().getStringExtra("p4");

        One.setText(ps1);
        Two.setText(ps2);
        Three.setText(ps3);
        Four.setText(ps4);

        ONE.setText(getIntent().getStringExtra("a1"));
        TWO.setText(getIntent().getStringExtra("a2"));
        THREE.setText(getIntent().getStringExtra("a3"));
        FOUR.setText(getIntent().getStringExtra("a4"));



    }
}
